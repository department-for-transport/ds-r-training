library(testthat)
library(labelVector)

test_check("labelVector")
