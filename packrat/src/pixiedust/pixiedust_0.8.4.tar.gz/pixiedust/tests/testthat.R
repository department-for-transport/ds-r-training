library("testthat")
library("pixiedust")

test_check("pixiedust")